// SJ MEDIA website interactions
// IMPORTANT: Replace the WhatsApp number below with your own business number in international format.
// Example Ghana number: 233XXXXXXXXX (omit the leading 0 and the + sign).
const SJ_MEDIA_WHATSAPP_NUMBER = "233XXXXXXXXX";

const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("contact-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const status = document.getElementById("form-status");
  const number = SJ_MEDIA_WHATSAPP_NUMBER.replace(/\D/g, "");

  if (!number || number.includes("XXXXXXXXX") || number.length < 10) {
    status.textContent = "Before this form can send enquiries, open script.js and replace SJ_MEDIA_WHATSAPP_NUMBER with your WhatsApp number in international format (for Ghana: 233 followed by your number, without the first 0).";
    return;
  }

  const form = new FormData(event.currentTarget);
  const message = [
    "Hello SJ MEDIA, I'd like to ask about a project.",
    "",
    `Name: ${form.get("name")}`,
    `Business: ${form.get("business")}`,
    `Service: ${form.get("service")}`,
    `Project details: ${form.get("message")}`
  ].join("\n");

  const whatsappUrl = `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
  window.open(whatsappUrl, "_blank", "noopener,noreferrer");
  status.textContent = "Your enquiry is prepared. If WhatsApp didn't open, check your browser's pop-up settings and try again.";
});
